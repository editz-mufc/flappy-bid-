This is the Cocos2D-SpriteBuilder Class Reference where you can look up public classes, methods, parameters, protocols, constants and enums. 
To learn how to work with Cocos2D (and SpriteBuilder) please refer to the [**Developer Guide**](http://www.makeschool.com/docs) 
and the [**Learn SpriteBuilder book**](http://www.apress.com/9781484202630).
