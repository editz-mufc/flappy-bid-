//
//  main.m
//  PROJECTNAME Mac
//
//  Created by Collin Jackson on 10/2/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
